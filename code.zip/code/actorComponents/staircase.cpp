c_staircase::c_staircase(c_actor* father, const int& direction)
: father(father),
  direction(direction) {
}