#ifndef c_dialogue_hpp
#define c_dialogue_hpp

class c_dialogue {

    private:
        

	public:

};

#endif