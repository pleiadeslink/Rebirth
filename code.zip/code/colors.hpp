sf::Color color(const std::string& str) {
    sf::Color color = sf::Color::White;
    if(str == "desaturated red") {
        color.r = 128;
        color.g = 64;
        color.b = 64;
        return color;
    } if(str == "lightest red") {
        color.r = 255;
        color.g = 191;
        color.b = 191;
        return color;
    } if(str == "lighter red") {
        color.r = 255;
        color.g = 166;
        color.b = 166;
        return color;
    } if(str == "light red") {
        color.r = 255;
        color.g = 155;
        color.b = 155;
        return color;
    } if(str == "red") {
        color.r = 255;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark red") {
        color.r = 191;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker red") {
        color.r = 128;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest red") {
        color.r = 64;
        color.g = 0;
        color.b = 0;return color;
    } if(str == "desaturated flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest flame") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "orange") {
        color.r = 255;
        color.g = 127;
        color.b = 0;
        return color;
    } if(str == "dark orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest orange") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated amber") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest amber") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter amber") {
        color.r = 255;
        color.g = 233;
        color.b = 166;
        return color;
    } if(str == "light amber") {
        color.r = 255;
        color.g = 220;
        color.b = 115;
        return color;
    } if(str == "amber") {
        color.r = 255;
        color.g = 191;
        color.b = 0;
        return color;
    } if(str == "dark amber") {
        color.r = 141;
        color.g = 153;
        color.b = 0;
        return color;
    } if(str == "darker amber") {
        color.r = 128;
        color.g = 96;
        color.b = 0;
        return color;
    } if(str == "darkest amber") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest yellow") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest lime") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker chartreuse") {
        color.r = 64;
        color.g = 128;
        color.b = 0;
        return color;
    } if(str == "darkest chartreuse") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated green") {
        color.r = 64;
        color.g = 128;
        color.b = 64;
        return color;
    } if(str == "lightest green") {
        color.r = 191;
        color.g = 255;
        color.b = 191;
        return color;
    } if(str == "lighter green") {
        color.r = 166;
        color.g = 255;
        color.b = 166;
        return color;
    } if(str == "light green") {
        color.r = 115;
        color.g = 255;
        color.b = 155;
        return color;
    } if(str == "green") {
        color.r = 0;
        color.g = 200;
        color.b = 0;
        return color;
    } if(str == "dark green") {
        color.r = 0;
        color.g = 191;
        color.b = 0;
        return color;
    } if(str == "darker green") {
        color.r = 55;
        color.g = 91;
        color.b = 33;
        return color;
    } if(str == "darkest green") {
        color.r = 41;
        color.g = 66;
        color.b = 28;
        return color;
    } if(str == "desaturated sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest sea") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest turquoise") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest cyan") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "sky") {
        color.r = 0;
        color.g = 191;
        color.b = 255;
        return color;
    } if(str == "dark sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest sky") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated azure") {
        color.r = 64;
        color.g = 96;
        color.b = 128;
        return color;
    } if(str == "lightest azure") {
        color.r = 191;
        color.g = 233;
        color.b = 255;
        return color;
    } if(str == "lighter azure") {
        color.r = 166;
        color.g = 210;
        color.b = 255;
        return color;
    } if(str == "light azure") {
        color.r = 115;
        color.g = 185;
        color.b = 255;
        return color;
    } if(str == "azure") {
        color.r = 95;
        color.g = 117;
        color.b = 181;
        return color;
    } if(str == "dark azure") {
        color.r = 56;
        color.g = 88;
        color.b = 143;
        return color;
    } if(str == "darker azure") {
        color.r = 32;
        color.g = 74;
        color.b = 98;
        return color;
    } if(str == "darkest azure") {
        color.r = 0;
        color.g = 32;
        color.b = 64;
        return color;
    } if(str == "desaturated blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest blue") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest han") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "violet") {
        color.r = 127;
        color.g = 0;
        color.b = 255;
        return color;
    } if(str == "dark violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest violet") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest purple") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest fuchsia") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest magenta") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lightest pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "lighter pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "light pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "dark pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darker pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "darkest pink") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "desaturated crimson") {
        color.r = 128;
        color.g = 64;
        color.b = 79;
        return color;
    } if(str == "lightest grey") {
        color.r = 233;
        color.g = 233;
        color.b = 233;
        return color;
    } if(str == "lighter grey") {
        color.r = 191;
        color.g = 191;
        color.b = 191;
        return color;
    } if(str == "light grey") {
        color.r = 159;
        color.g = 159;
        color.b = 159;
        return color;
    } if(str == "grey") {
        color.r = 127;
        color.g = 127;
        color.b = 127;
        return color;
    } if(str == "dark grey") {
        color.r = 95;
        color.g = 95;
        color.b = 95;
        return color;
    } if(str == "darker grey") {
        color.r = 63;
        color.g = 63;
        color.b = 63;
        return color;
    } if(str == "darkest grey") {
        color.r = 31;
        color.g = 31;
        color.b = 31;
        return color;
    } if(str == "lightest sepia") {
        color.r = 222;
        color.g = 211;
        color.b = 195;
        return color;
    } if(str == "lighter sepia") {
        color.r = 191;
        color.g = 171;
        color.b = 143;
        return color;
    } if(str == "light sepia") {
        color.r = 137;
        color.g = 111;
        color.b = 92;
        return color;
    } if(str == "sepia") {
        color.r = 127;
        color.g = 101;
        color.b = 63;
        return color;
    } if(str == "dark sepia") {
        color.r = 94;
        color.g = 75;
        color.b = 47;
        return color;
    } if(str == "darker sepia") {
        color.r = 63;
        color.g = 50;
        color.b = 31;
        return color;
    } if(str == "darkest sepia") {
        color.r = 31;
        color.g = 24;
        color.b = 15;
        return color;
    } if(str == "black") {
        color.r = 0;
        color.g = 0;
        color.b = 0;
        return color;
    } if(str == "gold") {
        color.r = 229;
        color.g = 191;
        color.b = 0;
        return color;
    } if(str == "copper") {
        color.r = 196;
        color.g = 136;
        color.b = 124;
        return color;
    } if(str == "brass") {
        color.r = 191;
        color.g = 151;
        color.b = 96;
        return color;
    }
    return color;
}