#ifndef c_assetManager_hpp
#define c_assetManager_hpp

class c_assetManager {
	private:
        sf::Font font;
        sf::Texture tileset;
        std::vector<structTextureAsset> v_textureAsset;
        std::vector<structActorAsset> v_actorAsset;
        std::vector<s_skillAsset> v_skillAsset;
        structMapAsset a_mapAsset[127][127][63];
        std::vector<structTileAsset> v_tileAsset;
        std::vector<structVerbAsset> v_verbAsset;
        //std::vector<structTopicAsset> v_topicAsset;
        int indexTile;
        int indexActor;
        void loadTiles();
        void loadActors();
        void loadSkills();
        structTileAsset clearTileAsset(structTileAsset asset);
        structActorAsset clearActorAsset(structActorAsset asset);
        s_skillAsset clearSkillAsset(s_skillAsset asset);
        structMapAsset clearMapAsset(structMapAsset asset);
	
    public:
        void load();
        sf::Font* getFont() { return &font; }
        sf::Texture* getTileset() { return &tileset; }
        sf::Texture* getTextureAsset(const std::string& id);
        structMapAsset* getMapAsset(const int& x, const int& y, const int& z);
        structTileAsset* getTileAsset(const std::string& id);
        std::vector<std::string> getTileIdList();
        structActorAsset* getActorAsset(const std::string& id);
        std::vector<std::string> getActorIdList();
        s_skillAsset* getSkillAsset(const std::string& id);
        structVerbAsset* getVerbAsset(const std::string& id);
};

#endif